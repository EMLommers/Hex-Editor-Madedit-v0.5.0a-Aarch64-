**Please provide the following information**

Madedit-Mod version (or branch):

platform/architecture:

compiler and compiler version:

please describe what symptom you see, what you would expect to see instead and how to reproduce it.


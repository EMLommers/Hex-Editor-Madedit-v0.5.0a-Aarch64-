Download more dictionaries at http://extensions.openoffice.org

Note:
oxt is actually a zip file. So, download it and open it with 7-zip. Then extract
the .dic and .aff to ./Dictionaries. Re-start MadEdit-Mod to load the dictionary.

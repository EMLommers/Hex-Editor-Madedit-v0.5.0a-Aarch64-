#! /bin/sh
find devcpp images image2xpm libunicows po src syntax vc71 xpressive wxAUI -type f -exec chmod 644 {} \;

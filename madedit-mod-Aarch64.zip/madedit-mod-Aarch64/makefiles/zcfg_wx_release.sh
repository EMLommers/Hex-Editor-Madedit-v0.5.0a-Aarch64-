# command line for configure of wxWidgets under linux
../configure --without-subdirs --disable-shared --disable-debug --enable-unicode --enable-stl --with-gnomeprint=yes --with-libpng=no --with-libjpeg=no --with-libtiff=no --with-regex=no --with-expat=no --with-zlib=no
#--with-expat=builtin

# for Makefile
# all: $(__basedll___depname) $(__baselib___depname) $(__coredll___depname) $(__corelib___depname)
# $(__wxexpat___depname)


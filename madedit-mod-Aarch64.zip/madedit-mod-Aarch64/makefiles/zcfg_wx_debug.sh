# command line for configure of wxWidgets under linux

../configure --without-subdirs --enable-shared --enable-debug --enable-unicode --enable-stl --with-gnomeprint=yes --with-libpng=no --with-libjpeg=no --with-libtiff=no --with-regex=no --with-expat=no --with-zlib=no
#--with-expat=builtin

# all: $(__basedll___depname) $(__baselib___depname) $(__coredll___depname) $(__corelib___depname)

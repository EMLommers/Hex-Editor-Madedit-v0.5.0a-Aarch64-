
../configure --with-wx-config=${HOME}/wxWidgets/RELEASE/wx-config --with-boost=${HOME}/boost --with-xpressive=${HOME}/boost LIBS="${HOME}/wxWidgets/RELEASE/lib/libwx_gtk2u_core-2.8.a ${HOME}/wxWidgets/RELEASE/lib/libwx_baseu-2.8.a -lgtk-x11-2.0 -lgthread-2.0 /usr/X11R6/lib/libXinerama.a" glib_gtk2_LIBS="-lm" WX_LIBS="-lm" CXXFLAGS="-O3 -fexpensive-optimizations"
